import cv2
import os
import time

# img = cv2.imread("galaxy.jpg",0)
# resized_img = cv2.resize(img,(1000,500))
# cv2.imshow("Galaxy",img)
# cv2.imwrite("",resized_img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

# for filename in os.listdir(r"./"):              #listdir的参数是文件夹的路径
#     if ".jpg" in filename:
#         img = cv2.imread(filename,0)
#         resized_img = cv2.resize(img, (100, 100))
#         cv2.imwrite("new_" + filename, resized_img)

# face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
# img = cv2.imread("photo.jpg")
# GRAY_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#
# faces = face_cascade.detectMultiScale(GRAY_img,scaleFactor=1.05,minNeighbors=5)
#
# for x,y,w,h in faces:
#     img = cv2.rectangle(img, (x,y),(x+w,y+h),(0,255,0),3)
#
# cv2.imshow("GRAY",img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

# while True:
#     video = cv2.VideoCapture(0)
#     check, frame = video.read()
#     gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
#     cv2.imshow("capturing",gray)
#     key = cv2.waitKey(1)
#     if key == ord('q'):
#         break
# video.release()
# cv2.destroyAllWindows()